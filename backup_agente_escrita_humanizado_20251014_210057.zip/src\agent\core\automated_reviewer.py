﻿class AutomatedReviewer:
    def __init__(self):
        pass

    def review(self, content):
        print('AutomatedReviewer: Revisando conteudo...')
        return content
