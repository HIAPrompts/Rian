﻿class HumanizedWriter:
    def __init__(self):
        pass

    def write(self, content):
        print('HumanizedWriter: Processando conteudo...')
        return content
